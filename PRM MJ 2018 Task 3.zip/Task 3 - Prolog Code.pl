character(jim).
character(jenny).
character(habib).

character_type(jim,prince).
character_type(jenny,princess).
character_type(habib,explorer).

pet(jim,horse).
pet(jenny,bird).
pet(habib,fish).

animal(horse).
animal(bird).
animal(fish).

skill(fly).
skill(invisibility).
skill(time_travel).

has_skill(jim,fly).
has_skill(jenny,invisibility).
has_skill(habib,time_travel).

has_skill(X,Y):-character(X),skill(Y).
have_pet(X,Y):-character(X),animal(Y).
tell_pet(X,Y):-character_type(Z,Y),pet(Z,X).

go:-
write('Enter type of character: '),
read(N), nl,
tell_pet(Y,N),
character_type(X,N),
write(N), write(' '), write(X), write(' has pet '),
write(Y).